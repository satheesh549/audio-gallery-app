import { Component, OnDestroy, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-audio-recorder',
  templateUrl: './audio-recorder.component.html',
  styleUrls: ['./audio-recorder.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class AudioRecorderComponent implements OnDestroy, AfterViewInit {
  @ViewChild('audioVisualizer') audioVisualizer!: ElementRef<HTMLCanvasElement>;
  
  @ViewChild('audioPlayer') audioPlayer!: ElementRef<HTMLAudioElement>;
  
  recordingState: 'idle' | 'recording' | 'recorded' = 'idle';
  private audioContext: AudioContext | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array | null = null;
  private stream: MediaStream | null = null;
  private animationFrameId: number | null = null;
  
  recordingTime = 0;
  private recordingTimer: any;
  audioUrl: string | null = null;
  audioBlob: Blob | undefined;
  isPlaying!: boolean;

  ngAfterViewInit() {
    this.setupVisualizer();
  }

  ngOnDestroy() {
    this.cleanUp();
  }

  async startRecording() {
    try {
      this.recordingState = 'recording';
      this.recordingTime = 0;
      this.audioChunks = [];
  
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  
      const source = this.audioContext.createMediaStreamSource(this.stream);
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 256;
      source.connect(this.analyser);
  
      this.dataArray = new Uint8Array(this.analyser.frequencyBinCount);
  
      this.mediaRecorder = new MediaRecorder(this.stream);
      this.mediaRecorder.ondataavailable = (event) => {
        this.audioChunks.push(event.data);
      };
  
      this.mediaRecorder.onstop = () => {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        this.audioUrl = URL.createObjectURL(audioBlob);
        this.recordingState = 'recorded';
      };
  
      this.mediaRecorder.start();
      this.startTimer();
      this.startVisualization();
  
      // Auto-stop after 30 seconds
      setTimeout(() => {
        if (this.recordingState === 'recording') {
          console.log('Auto-stopping recording after 30 seconds');
          this.stopRecording();
        }
      }, 30000);
    } catch (error) {
      console.error('Error starting recording:', error);
      this.recordingState = 'idle';
      this.cleanUp();
    }
  }

  stopRecording() {
    if (this.recordingState !== 'recording') return;
  
    console.log('Stopping recording...');
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
    }
  
    this.cleanUpTemporaryResources();
    this.recordingState = 'recorded';
  }
  // playRecording() {
  //   if (!this.audioBlob) {
  //     console.error('No audio blob available to play');
  //     return;
  //   }
  
  //   // Create a new object URL each time to avoid caching issues
  //   const audioUrl = URL.createObjectURL(this.audioBlob);
  //   const audioPlayer = this.audioPlayer.nativeElement;
  
  //   // Clean up any previous audio source
  //   audioPlayer.pause();
  //   audioPlayer.currentTime = 0;
  //   audioPlayer.src = '';
  
  //   // Set up new audio source
  //   audioPlayer.src = audioUrl;
  //   audioPlayer.load(); // Important for iOS devices
  
  //   const playPromise = audioPlayer.play();
  
  //   if (playPromise !== undefined) {
  //     playPromise.then(() => {
  //       console.log('Playback started successfully');
  //       this.isPlaying = true;
        
  //       // Clean up the object URL when playback ends
  //       audioPlayer.onended = () => {
  //         URL.revokeObjectURL(audioUrl);
  //         this.isPlaying = false;
  //       };
  //     })
  //     .catch(error => {
  //       console.error('Playback failed:', error);
  //       URL.revokeObjectURL(audioUrl);
  //       this.isPlaying = false;
        
  //       // Show user-friendly error message
  //       alert('Playback failed. Please try again or check your audio settings.');
  //     });
  //   }
  // }
  playRecording() {
    if (!this.audioUrl) {
      console.error('No audio URL available to play');
      return;
    }
  
    // Ensure the audioPlayer element is initialized
    if (!this.audioPlayer || !this.audioPlayer.nativeElement) {
      console.error('Audio player element is not initialized');
      return;
    }
  
    const audioPlayer = this.audioPlayer.nativeElement;
  
    // Stop any ongoing playback
    audioPlayer.pause();
    audioPlayer.currentTime = 0;
  
    // Set the audio source and play
    audioPlayer.src = this.audioUrl;
    audioPlayer.load(); // Ensure the audio is loaded
    const playPromise = audioPlayer.play();
  
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          console.log('Playback started successfully');
          this.isPlaying = true;
  
          // Handle playback end
          audioPlayer.onended = () => {
            this.isPlaying = false;
          };
        })
        .catch((error) => {
          console.error('Playback failed:', error);
          this.isPlaying = false;
  
          // Show user-friendly error message
          alert('Playback failed. Please try again or check your audio settings.');
        });
    }
  }

  cancelRecording() {
    this.recordingState = 'idle';
    this.audioUrl = null;
    this.recordingTime = 0;
    this.cleanUp();
  }

  private setupVisualizer() {
    const canvas = this.audioVisualizer?.nativeElement;
    const ctx = canvas?.getContext('2d');
    if (!ctx) return;
    
    // Set canvas dimensions to match display size
    const width = canvas.offsetWidth;
    const height = canvas.offsetHeight;
    canvas.width = width;
    canvas.height = height;
  }

  private startVisualization() {
    if (!this.analyser || !this.dataArray) return;
    
    const canvas = this.audioVisualizer.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const width = canvas.width;
    const height = canvas.height;
    
    const draw = () => {
      this.animationFrameId = requestAnimationFrame(draw);
      
      this.analyser!.getByteFrequencyData(this.dataArray!);
      
      ctx.fillStyle = 'rgb(240, 240, 240)';
      ctx.fillRect(0, 0, width, height);
      
      const barWidth = (width / this.analyser!.frequencyBinCount) * 2.5;
      let x = 0;
      
      for (let i = 0; i < this.analyser!.frequencyBinCount; i++) {
        const barHeight = (this.dataArray![i] / 255) * height;
        
        // Create gradient for bars
        const gradient = ctx.createLinearGradient(0, height - barHeight, 0, height);
        gradient.addColorStop(0, '#4285f4');
        gradient.addColorStop(1, '#34a853');
        
        ctx.fillStyle = gradient;
        ctx.fillRect(x, height - barHeight, barWidth, barHeight);
        
        x += barWidth + 1;
      }
    };
    
    draw();
  }

  private startTimer() {
    this.recordingTimer = setInterval(() => {
      this.recordingTime++;
    }, 1000);
  }

  private cleanUpTemporaryResources() {
    clearInterval(this.recordingTimer);
    
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
    
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    
    this.analyser = null;
    this.dataArray = null;
    this.audioContext = null;
    this.mediaRecorder = null;
  }

  private cleanUp() {
    this.cleanUpTemporaryResources();
    
    if (this.audioUrl) {
      URL.revokeObjectURL(this.audioUrl);
      this.audioUrl = null;
    }
  }

  get formattedTime() {
    const minutes = Math.floor(this.recordingTime / 60);
    const seconds = this.recordingTime % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  private setupMediaRecorder() {
    if (!this.mediaRecorder) return;
    
    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data.size > 0) {
        this.audioChunks.push(event.data);
      }
    };
    
    this.mediaRecorder.onstop = () => {
      // Create the audio blob in the correct format
      this.audioBlob = new Blob(this.audioChunks, { type: 'audio/mp3' }); // or 'audio/wav'
      
      // Create object URL for playback
      this.audioUrl = URL.createObjectURL(this.audioBlob);
      
      this.recordingState = 'recorded';
      this.cleanUpTemporaryResources();
      console.log('Recording stopped, audio blob created', this.audioBlob);
    };
  }
  stopPlayback() {
    if (this.audioPlayer?.nativeElement) {
      this.audioPlayer.nativeElement.pause();
      this.audioPlayer.nativeElement.currentTime = 0;
      this.isPlaying = false;
    }
  }
  
}