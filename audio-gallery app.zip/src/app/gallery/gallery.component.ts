import { Component, AfterViewInit } from '@angular/core';
import { Swiper } from 'swiper';
import 'swiper/swiper-bundle.css';
import { CommonModule } from '@angular/common';
import { SwiperOptions } from 'swiper/types';
import { SwiperContainer } from 'swiper/element';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss'],
  imports: [CommonModule],
  standalone: true  
})
export class GalleryComponent implements AfterViewInit {
  images = [
    { id: 1, url: 'https://picsum.photos/id/10/800/500' },
    { id: 2, url: 'https://picsum.photos/id/11/800/500' },
    { id: 3, url: 'https://picsum.photos/id/12/800/500' },
    { id: 4, url: 'https://picsum.photos/id/13/800/500' },
    { id: 5, url: 'https://picsum.photos/id/14/800/500' }
  ];
  
  currentIndex = 0;
  private swiper!: Swiper;

  ngAfterViewInit() {
    this.initSwiper();
  }

  private initSwiper() {
    this.swiper = new Swiper('.swiper-container', {
      loop: false,
      pagination: {
        el: '.swiper-pagination',
        clickable: true
      },
      on: {
        slideChange: () => {
          this.currentIndex = this.swiper.realIndex;
        }
      }
    });
  }

  goToSlide(index: number) {
    this.swiper.slideTo(index);
  }
}